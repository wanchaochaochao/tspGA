clear;clc;
probmutation = 0.16;  
h=20;
popSize=h;
a=[0 5 16 20 33 23 35 25 10;15 20 24 20 25 11 7 0 3];
hh=length(a);
hhh=200;
for i=1:hh;
    for j=1:hh;
b(i,j)=sqrt((a(1,i)-a(1,j))^2+(a(2,i)-a(2,j))^2);
    end;
end;
for i=1:(h);
    c(i,:)=randperm(hh);
end;
for l=1:hhh;
    d(1:h)=0;
%for i=1:h;
 %   c(i,11)=c(i,1);
  %  for j=1:10;
 %d(i)=b(c(i,j),c(i,j+1))+d(i);
%end;
%end;
%for j=1:h;
%    if d(j)==min(d);
%        g(l)=j;
 %       e(l,:)=c(j,:);
%        f(l)=min(d);
        %for k=1:10;
        %    plot([a(1,c(j,k)) a(1,c(j,k+1))],[a(2,c(j,k)) a(2,c(j,k+1))],'-')
        %end;
 %   end;
%end;
popDist = totaldistance(c,b);
 fitness = 1./popDist;
   
    % find the best route & distance
    [mindist, bestID] = min(popDist); 
    bestPop = c(bestID, :);       % best route
    
    % update best route on figure:
    
    % select (competition / roulette)
    c = select(c, fitness, popSize,'competition');
    
    % crossover
    c = crossover(c);
    
    % mutation
    c = mutation(c, probmutation);
   
    % save elitism(best path) and put it to next generation without changes
    c = [bestPop; c];
  %   c =crossover(c(:,1:10));
  %   c = mutation(c(:,1:10), probmutation);
 %    for i=1:l
 %        if f(i)==min(f);
             
 %    c(g(l),:)=c(e(l,1:10))
 %        end;
%end;
end;
[mindist, bestID]=min(popDist); 
bestPop = c(bestID, :);
e=bestPop;
e(:,(hh+1))=e(:,1);
disp('���Ž�Ϊ��\n');
disp(mindist);
%for i=1:200;
 %   if f(i)==min(f);
 i=1;
 hold on;
        for k=1:hh;
    plot(a(1,k),a(2,k),'ro');
            plot([a(1,e(i,k)) a(1,e(i,k+1))],[a(2,e(i,k)) a(2,e(i,k+1))],'-');
        end;
        hold off;
 %   end;
%end;